class SmoothedRollingMean:
    pass
