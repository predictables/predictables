import pytest
import polars as pl
# from predictables.encoding.src.lagged_mean_encoding._dynamic_rolling_sum import min_date, max_date, n_dates
