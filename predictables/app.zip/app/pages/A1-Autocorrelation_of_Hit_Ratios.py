"""Define the autocorrelation of hit ratios page of the Predictables app."""

import streamlit as st

st.markdown("# Autocorrelation of Hit Ratios")

st.write("This page will show the autocorrelation of hit ratios.")

# leave a space for an autocorrelation plot
st.write("Autocorrelation plot will go here.")