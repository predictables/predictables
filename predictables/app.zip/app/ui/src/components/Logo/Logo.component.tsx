import './Logo.styles.css';

const Logo: React.FC = () => {
  return (
    <div className="logo">
      Logo
    </div>
  );
};

export default Logo;
