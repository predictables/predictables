const NavbarInfo = () => {
  return (
    <div>NavbarInfo</div>
  )
}

export default NavbarInfo