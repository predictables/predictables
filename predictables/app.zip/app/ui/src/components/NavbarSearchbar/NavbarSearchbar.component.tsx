const NavbarSearchbar = () => {
  return (
    <div>NavbarSearchbar</div>
  )
}

export default NavbarSearchbar