def perform_correlation_analysis(dataset, target_variable, cv_folds):
    pass


def calc_predictor_target_corr(dataset, target_variable):
    pass


def visualize_correlations(correlations):
    pass


def highlight_extreme_correlations(correlations):
    pass
