from .core import PredicTables  # noqa F401
