# trunk-ignore-all(flake8/F401)
from ._assert_df_size_change import (
    assert_df_size_change as assert_df_size,  # noqa: F401
)  # noqa: F401
