from ._UnivariateAnalysis import UnivariateAnalysis  # noqa F401
